package com.example.handmadetrail.Repository;

import com.example.handmadetrail.Model.CompletedProject;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface CompletedProjectRepository extends JpaRepository<CompletedProject, Integer> {
    // Using find
    CompletedProject findOngoingProjectByCompletedProjectId(Integer completedProjectId);

    // Using JPQL
    @Query("select cp from CompletedProject CP where cp.diyBeginnerId = ?1 and cp.completeDate > ?2")
    List<CompletedProject> getAllCompletedProjectsByDiyBeginnerIdAndDate(Integer diyBeginnerId, LocalDateTime date);
}