package com.example.handmadetrail.Model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Check;

@Data
@AllArgsConstructor
@Entity
@NoArgsConstructor
public class MaterialMerchantStock {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer materialMerchantStockId;

    @NotNull(message = "Material id can't be null.")
    @Column(columnDefinition = "int not null")
    private Integer materialId;

    @NotNull(message = "Material merchant id can't be null.")
    @Column(columnDefinition = "int not null")
    private Integer materialMerchantId;

    @NotNull(message = "Stock can't be empty.")
    @Positive(message = "Stock must be a positive number larger than zero.")
    @Column(columnDefinition = "int not null")
    @Check(constraints = "stock > 0")
    private Integer stock;
}