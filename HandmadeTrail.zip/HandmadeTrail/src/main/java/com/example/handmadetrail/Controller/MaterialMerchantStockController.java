package com.example.handmadetrail.Controller;


import com.example.handmadetrail.ApiResponse.ApiResponse;
import com.example.handmadetrail.Model.MaterialMerchantStock;
import com.example.handmadetrail.Servise.MaterialMerchantStockService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/materialMerchantStock")
@RequiredArgsConstructor
public class MaterialMerchantStockController {
    // 1. Declare a dependency for MaterialMerchantStockService using Dependency Injection
    private final MaterialMerchantStockService materialMerchantStockService;

    // 2. CRUD
    // 2.1 Get
    @GetMapping("/get")
    public ResponseEntity getAllMaterialMerchantStocks() {
        return ResponseEntity.status(200).body(materialMerchantStockService.getAllMaterialMerchantStocks());
    }

    // 2.2 Post
    @PostMapping("/add")
    public ResponseEntity addMaterialMerchantStock(@RequestBody @Valid MaterialMerchantStock materialMerchantStock, Errors errors) {
        if (errors.hasErrors()) {
            return ResponseEntity.status(400).body(errors.getFieldError().getDefaultMessage());
        }
        materialMerchantStockService.addMaterialMerchantStock(materialMerchantStock);
        return ResponseEntity.status(200).body(new ApiResponse("New Material Merchant Stock Added."));
    }

    // 2.3 Update
    @PutMapping("/update/{materialMerchantStockId}")
    public ResponseEntity updateMaterialMerchantStock(@PathVariable Integer materialMerchantStockId, @RequestBody @Valid MaterialMerchantStock materialMerchantStock, Errors errors) {
        if (errors.hasErrors()) {
            return ResponseEntity.status(400).body(errors.getFieldError().getDefaultMessage());
        }
        materialMerchantStockService.updateMaterialMerchantStock(materialMerchantStockId, materialMerchantStock);
        return ResponseEntity.status(200).body(new ApiResponse("Material Merchant Stock Updated."));
    }

    // 2.4 Delete
    @DeleteMapping("/delete/{materialMerchantStockId}")
    public ResponseEntity deleteMaterialMerchantStock(@PathVariable Integer materialMerchantStockId) {
        materialMerchantStockService.deleteMaterialMerchantStock(materialMerchantStockId);
        return ResponseEntity.status(200).body(new ApiResponse("Material Merchant Stock Deleted."));
    }

    // 3. Extra endpoints
    // Add more material stock
    @PutMapping("/addStock/{materialMerchantId}/{materialId}/{amount}")
    public ResponseEntity addStock(@PathVariable Integer materialMerchantId, @PathVariable Integer materialId, @PathVariable Integer amount) {
        materialMerchantStockService.addStock(materialMerchantId, materialId, amount);
        return ResponseEntity.status(200).body(new ApiResponse("New Material Stock Added."));
    }
}