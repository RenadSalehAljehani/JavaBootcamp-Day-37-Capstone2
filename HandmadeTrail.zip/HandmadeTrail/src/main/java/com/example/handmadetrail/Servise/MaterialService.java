package com.example.handmadetrail.Servise;

import com.example.handmadetrail.ApiResponse.ApiException;
import com.example.handmadetrail.Model.Material;
import com.example.handmadetrail.Repository.MaterialRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class MaterialService {

    // 1. Declare a dependency for MaterialRepository using Dependency Injection
    private final MaterialRepository materialRepository;

    // 2. CRUD
    // 2.1 Get
    public List<Material> getAllMaterials() {
        return materialRepository.findAll();
    }

    // 2.2 Post
    public void addMaterial(Material material) {
        materialRepository.save(material);
    }

    // 2.3 Update
    public void updateMaterial(Integer materialId, Material material) {
        // 1. Check if material to be updated exists
        Material oldMaterial = materialRepository.findMaterialByMaterialId(materialId);
        if (oldMaterial == null) {
            throw new ApiException("Material Not Found.");
        }
        // 2. Set new values
        oldMaterial.setName(material.getName());
        oldMaterial.setPrice(material.getPrice());

        // 3. Save changes
        materialRepository.save(oldMaterial);
    }

    // 2.4 Delete
    public void deleteMaterial(Integer materialId) {
        // Check if material to be deleted exists
        Material oldMaterial = materialRepository.findMaterialByMaterialId(materialId);
        if (oldMaterial == null) {
            throw new ApiException("Material Not Found.");
        }
        materialRepository.delete(oldMaterial);
    }

    // 3.Extra endpoint
    // An endpoint to get all materials by a price range
    public List<Material> getAllMaterialsByPriceRange(Double minPrice, Double maxPrice) {
        List<Material> materials = materialRepository.getAllMaterialsByPriceRange(minPrice, maxPrice);

        if (materials.isEmpty()) {
            throw new ApiException("No Materials Within Specified Price Range Has Been Found.");
        }
        return materials;
    }
}