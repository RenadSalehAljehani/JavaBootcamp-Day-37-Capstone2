package com.example.handmadetrail.Repository;

import com.example.handmadetrail.Model.MaterialMerchantStock;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MaterialMerchantStockRepository extends JpaRepository<MaterialMerchantStock, Integer> {
    // Using find
    MaterialMerchantStock findMaterialMerchantStockByMaterialMerchantStockId(Integer materialMerchantStockId);

    //MaterialMerchantStock findMaterialMerchantStockByMaterialId(Integer materialId);

    MaterialMerchantStock findMaterialMerchantStockByMaterialMerchantIdAndMaterialId(Integer materialMerchantId, Integer materialId);
}