package com.example.handmadetrail.Servise;

import com.example.handmadetrail.ApiResponse.ApiException;
import com.example.handmadetrail.Model.MaterialMerchantStock;
import com.example.handmadetrail.Repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class MaterialMerchantStockService {

    // 1. Declare a dependency for MaterialMerchantStockRepository using Dependency Injection
    private final MaterialMerchantStockRepository materialMerchantStockRepository;

    // 2. Declare a dependency for MaterialMerchantRepository using Dependency Injection
    private final MaterialMerchantRepository materialMerchantRepository;

    // 3. Declare a dependency for MaterialRepository using Dependency Injection
    private final MaterialRepository materialRepository;

    // 4. CRUD
    // 4.1 Get
    public List<MaterialMerchantStock> getAllMaterialMerchantStocks() {
        return materialMerchantStockRepository.findAll();
    }

    // 4.2 Post
    public void addMaterialMerchantStock(MaterialMerchantStock materialMerchantStock) {
        // Check the existence of material id and material merchant id
        boolean invalidMaterialId = materialRepository.findMaterialByMaterialId(materialMerchantStock.getMaterialId()) == null;
        boolean invalidMaterialMerchantId = materialMerchantRepository.findMaterialMerchantByMaterialMerchantId(materialMerchantStock.getMaterialMerchantId()) == null;

        if (invalidMaterialId && invalidMaterialMerchantId) {
            throw new ApiException("Material and Material Merchant Not Found.");
        }
        if (invalidMaterialId) {
            throw new ApiException("Material Not Found.");
        }
        if (invalidMaterialMerchantId) {
            throw new ApiException("Material Merchant Not Found.");
        }
        materialMerchantStockRepository.save(materialMerchantStock);
    }

    // 4.3 Update
    public void updateMaterialMerchantStock(Integer materialMerchantStockId, MaterialMerchantStock materialMerchantStock) {
        // 1. Check if material merchant stock to be updated exists
        MaterialMerchantStock oldMaterialMerchantStock = materialMerchantStockRepository.findMaterialMerchantStockByMaterialMerchantStockId(materialMerchantStockId);
        if (oldMaterialMerchantStock == null) {
            throw new ApiException("Material Merchant Stock Not Found.");
        }

        // 2. Check the existence of material id and material merchant id
        boolean invalidMaterialId = materialRepository.findMaterialByMaterialId(materialMerchantStock.getMaterialId()) == null;
        boolean invalidMaterialMerchantId = materialMerchantRepository.findMaterialMerchantByMaterialMerchantId(materialMerchantStock.getMaterialMerchantId()) == null;

        if (invalidMaterialId && invalidMaterialMerchantId) {
            throw new ApiException("Material and Material Merchant Not Found.");
        }
        if (invalidMaterialId) {
            throw new ApiException("Material Not Found.");
        }
        if (invalidMaterialMerchantId) {
            throw new ApiException("Material Merchant Not Found.");
        }

        // 3. Set new values
        oldMaterialMerchantStock.setMaterialId(materialMerchantStock.getMaterialId());
        oldMaterialMerchantStock.setMaterialMerchantId(materialMerchantStock.getMaterialMerchantId());
        oldMaterialMerchantStock.setStock(materialMerchantStock.getStock());

        // 4. Save changes
        materialMerchantStockRepository.save(oldMaterialMerchantStock);
    }

    // 4.4 Delete
    public void deleteMaterialMerchantStock(Integer materialMerchantStockId) {
        // Check if material merchant stock to be deleted exists
        MaterialMerchantStock oldMaterialMerchantStock = materialMerchantStockRepository.findMaterialMerchantStockByMaterialMerchantStockId(materialMerchantStockId);
        if (oldMaterialMerchantStock == null) {
            throw new ApiException("Material Merchant Stock Not Found.");
        }
        materialMerchantStockRepository.delete(oldMaterialMerchantStock);
    }

    // 5. Extra endpoints
    // An endpoint to allow merchant to add more material stock
    public void addStock(Integer materialMerchantId, Integer materialId, Integer amount) {
        // 1. Check if amount is valid
        if (amount <= 0) {
            throw new ApiException("Material Amount Should Be a Positive Number Larger Than Zero.");
        }

        // 2. Check the existence of material merchant id and material id
        boolean invalidMaterialMerchantId = materialMerchantRepository.findMaterialMerchantByMaterialMerchantId(materialMerchantId) == null;
        boolean invalidMaterialId = materialRepository.findMaterialByMaterialId(materialId) == null;

        if (invalidMaterialMerchantId && invalidMaterialId) {
            throw new ApiException("Material Merchant and Material Not Found.");
        }
        if (invalidMaterialMerchantId) {
            throw new ApiException("Material Merchant Not Found.");
        }
        if (invalidMaterialId) {
            throw new ApiException("Material Not Found.");
        }

        // 3. Check if material merchant stock exists
        MaterialMerchantStock materialMerchantStock = materialMerchantStockRepository.findMaterialMerchantStockByMaterialMerchantIdAndMaterialId(materialMerchantId, materialId);

        if (materialMerchantStock == null) {
            throw new ApiException("Material Merchant Stock Not Found.");
        }

        // 4. Add stock
        materialMerchantStock.setStock(materialMerchantStock.getStock() + amount);

        // 5. Save the changes
        materialMerchantStockRepository.save(materialMerchantStock);
    }
}