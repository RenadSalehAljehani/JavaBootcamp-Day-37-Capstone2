package com.example.handmadetrail;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HandmadeTrailApplication {

    public static void main(String[] args) {
        SpringApplication.run(HandmadeTrailApplication.class, args);
    }

}
