package com.example.handmadetrail.Model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Check;

@Data
@AllArgsConstructor
@Entity
@NoArgsConstructor
public class MaterialMerchant {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer materialMerchantId;

    @NotEmpty(message = "Name can't be null.")
    @Size(min = 5, max = 10, message = "Name length must be between 5-10 characters.")
    @Column(columnDefinition = "varchar(10) not null")
    @Check(constraints = "length(name) >= 5")
    private String name;
}